# 后续实现说明

## 当前产品状态

本仓库是基于 `sapphire-xu/nidong` 桌面壳适配的无锡学院主题桌面看板，属于非官方项目，未获得学校授权或背书。现阶段只提供桌面岛、Fluent 看板、本机日程、周视图、日程提醒和本地设置。

无锡学院个人课表登录与同步已接入，校园卡、宿舍和校园网接口仍未接入。首次使用允许用户创建本机昵称并保存教务账号；用户名保存在本机 `settings.json`，密码使用独立的系统凭据库条目，绝不能写入普通设置、日志或前端持久化。资料页提供删除账号和密码的操作。课表同步仅访问 `https://jwgl.cwxu.edu.cn`，动态获取 RSA 公钥、使用 HTTPS 提交凭据；重定向只允许官方主机，遇到 HTTP 跳转会先升级到 HTTPS。不得保存会话 Cookie 或绕过验证码、短信及额外验证，也不读取浏览器登录会话。保存资料后首次同步或用户手动同步时才提交账号；首个真实账号同步尚需由用户在本机确认。不要复用东北大学的认证、课表或校园网接口。

## 界面与架构

- 保留顶部 420×40 置顶桌面岛和系统标题栏的 Fluent 桌面窗口。
- 校园卡、宿舍和校园网数据尚未接入时，显示“待接入”，不要编造余额、课程、宿舍或账号状态；课表只展示学校接口实际返回的课程。
- 本机日程保存在本机，继续使用现有 agenda 模型和窗口内周视图。
- 只开放已核实的学校官方页面：官网 `https://www.cwxu.edu.cn/`、教务登录页 `https://jwgl.cwxu.edu.cn/jwglxt/xtgl/login_slogin.html`，以及用户提供的个人课表查询页 `https://jwgl.cwxu.edu.cn/jwglxt/kbcx/xskbcx_cxXsgrkb.html?gnmkdm=N2151`。Tauri `open_door` 只允许精确匹配这些地址。
- 用户手动确认个人课表请求为 `POST /jwglxt/kbcx/xskbcx_cxXsgrkb.html?gnmkdm=N2151`，表单编码为 `application/x-www-form-urlencoded`；已知学期参数 `xnm`/`xqm` 当前值为 `2026`/`3`，其它字段包括 `kzlx=ck`、空值 `xsdm`/`kclbdm`/`kclxdm`。课程字段映射包括 `kcmc`、`cdmc`、`jcs`、`xqj`、`zcd`、`xqmc`；`xm` 可能是学生姓名，不能把它当作任课教师。登录 POST 为 `/jwglxt/xtgl/login_slogin.html`，表单字段为 `csrftoken`、`language=zh_CN`、空 `ydType`、`yhm`、`mm`；公钥由 `/jwglxt/xtgl/login_getPublicKey.html` 返回 `modulus`/`exponent`。具体字段值、Cookie 和密文都不得提交到仓库或日志。自动同步失败时保留旧缓存。无锡学院官方 1–11 节时间按用户提供的《学校上课时间表.pdf》写入看板。不要复用历史 NEU 端点。
- 主题采用克制的蓝绿色；不要使用未经确认的校徽、官方 VI 或授权声明。

## 主要位置

- `ui/src/App.tsx`：顶部桌面岛
- `ui/src/desk/DeskApp.tsx`：桌面窗口和导航
- `ui/src/desk/pages/`：看板、日程、学校服务、设置和关于
- `ui/src/Settings.tsx`：外观、启动、桌面岛和日程提醒设置
- `src-tauri/src/agenda.rs`：本机日程读写
- `src-tauri/src/lib.rs`：Tauri 状态、命令、窗口和托盘

`docs/开发文档.md` 保留的是上游 NEU 版本的历史记录，不是无锡学院接口资料，不能将其中的域名、流程或参数用于本项目。

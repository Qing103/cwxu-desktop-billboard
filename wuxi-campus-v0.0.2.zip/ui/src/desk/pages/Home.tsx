import { Button, Card } from "@fluentui/react-components";
import { Add20Regular, CalendarLtr20Regular } from "@fluentui/react-icons";
import type { Agenda, AppSettings, Course, Snapshot } from "../../types";
import { deriveDay } from "../../dayModel";
import type { MixRow } from "../../agenda";

function AgendaRow({ row, onOpen }: { row: MixRow; onOpen: () => void }) {
  return (
    <button type="button" className={`mix-row ${row.kind}`} onClick={onOpen}>
      <div className="when"><span className="num">{row.end ? `${row.start}–${row.end}` : row.start}</span></div>
      <div className="cname"><span className="cname-main"><i className="kind-dot" aria-hidden="true" />{row.name}</span></div>
      <div className="place">{row.meta || "本机日程"}</div>
    </button>
  );
}

export function Home(props: {
  snap: Snapshot | null;
  settings: AppSettings | null;
  now: Date;
  courseSyncBusy: boolean;
  courseSyncError: string;
  onSyncCourses: () => void;
  onOpenSettings: () => void;
  onOpenSchedule: () => void;
  onOpenEvent: (item: Agenda | null) => void;
  onOpenCourse: (course: Course | null) => void;
}) {
  const day = deriveDay(props.snap, props.settings, props.now);
  const todayRows = day.todayMix;
  const dateLabel = props.now.toLocaleDateString("zh-CN", {
    year: "numeric",
    month: "long",
    day: "numeric",
    weekday: "long",
  });
  const courseCount = props.snap?.semester?.courses.length || 0;
  const hasJwxtCredentials = Boolean(props.settings?.jwxtUsername && props.settings?.jwxtPasswordSaved);
  const courseStatus = props.courseSyncBusy
    ? "同步中…"
    : courseCount > 0
      ? `${courseCount} 门课程`
      : hasJwxtCredentials
        ? "尚未同步"
        : "未设置账号";
  const courseDetail = courseCount > 0
    ? `最近同步：${props.snap?.semester?.fetchedAt || "已更新"}`
    : hasJwxtCredentials
      ? "点击同步获取本学期课表"
      : "在设置中保存教务账号后即可同步";

  return (
    <div className="stack">
      <div className="row-between">
        <h1 className="page-title">无锡学院</h1>
        <span className="hint">{dateLabel}</span>
      </div>
      <div className="about-lead">尚德笃行 · 求是鼎新</div>
      {props.settings?.displayName ? <p className="hint">欢迎回来，{props.settings.displayName}</p> : null}
      <div className="row-between">
        <p className="hint">桌面看板 · 教务数据仅用于本机课表展示</p>
        <Button
          appearance="primary"
          disabled={props.courseSyncBusy}
          onClick={hasJwxtCredentials ? props.onSyncCourses : props.onOpenSettings}
        >
          {props.courseSyncBusy ? "正在同步…" : hasJwxtCredentials ? "同步教务课表" : "设置教务账号"}
        </Button>
      </div>
      {props.courseSyncError ? <p className="hint warn" role="alert">{props.courseSyncError}</p> : null}

      <div className="cards">
        {[
          ["教务课表", courseStatus, courseDetail],
          ["校园卡", "待接入", "校园卡余额与消费记录"],
          ["校园服务", "待接入", "宿舍、网络等服务数据"],
        ].map(([title, state, detail]) => (
          <Card key={title}>
            <div className="card-hit">
              <div className="card-k">{title}</div>
              <div className="card-v">{state}</div>
              <div className="card-u">{detail}</div>
            </div>
          </Card>
        ))}
      </div>

      <div className="row-between">
        <strong>今日安排</strong>
        <div>
          <Button appearance="subtle" disabled={!props.snap?.semester} icon={<Add20Regular />} onClick={() => props.onOpenCourse(null)}>添加课程</Button>
          <Button appearance="subtle" icon={<Add20Regular />} onClick={() => props.onOpenEvent(null)}>添加日程</Button>
          <Button appearance="subtle" icon={<CalendarLtr20Regular />} onClick={props.onOpenSchedule}>周视图</Button>
        </div>
      </div>
      {todayRows.length ? (
        <div className="mix">
          {todayRows.map((row) => (
            <AgendaRow key={row.key} row={row} onOpen={() => row.type === "course" ? row.course && props.onOpenCourse(row.course) : row.event && props.onOpenEvent(row.event)} />
          ))}
        </div>
      ) : (
        <div className="empty">今天没有课程或本机日程。</div>
      )}
      <div className="foot">无锡学院桌面看板为非官方适配版；教务课表通过学校官方 HTTPS 接口同步。</div>
    </div>
  );
}

import { useState } from "react";
import {
  Button,
  Dialog,
  DialogBody,
  DialogContent,
  DialogSurface,
  DialogTitle,
  Field,
  Input,
} from "@fluentui/react-components";
import type { Course } from "./types";

const STARTS = ["08:00", "08:55", "10:10", "11:05", "13:45", "14:40", "15:55", "16:50", "18:45", "19:40", "20:35"];
const ENDS = ["08:45", "09:40", "10:55", "11:50", "14:30", "15:25", "16:40", "17:35", "19:30", "20:25", "21:20"];
const DAY_NAMES = ["", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六", "星期日"];

function compactWeeks(weeks?: number[]) {
  if (!weeks?.length) return "";
  const sorted = [...new Set(weeks)].sort((a, b) => a - b);
  const ranges: string[] = [];
  for (let i = 0; i < sorted.length;) {
    let end = i;
    while (end + 1 < sorted.length && sorted[end + 1] === sorted[end] + 1) end++;
    ranges.push(i === end ? `${sorted[i]}` : `${sorted[i]}-${sorted[end]}`);
    i = end + 1;
  }
  return ranges.join(",");
}

function parseWeeks(raw: string): number[] | undefined {
  const value = raw.trim().replace(/周/g, "").replace(/[，、；;]/g, ",");
  if (!value) return undefined;
  const weeks = new Set<number>();
  for (const token of value.split(",").map((part) => part.trim()).filter(Boolean)) {
    const match = token.match(/^(\d{1,2})(?:\s*[-~—–]\s*(\d{1,2}))?$/);
    if (!match) throw new Error("周次请按 1-3,6-8 填写；留空表示每周。");
    const first = Number(match[1]);
    const last = Number(match[2] || match[1]);
    if (first < 1 || last > 30 || last < first) throw new Error("周次须在第 1 至 30 周内，且结束周不能早于开始周。");
    for (let week = first; week <= last; week++) weeks.add(week);
  }
  return [...weeks].sort((a, b) => a - b);
}

export function CourseForm(props: {
  open: boolean;
  initial: Course | null;
  busy?: boolean;
  err?: string;
  onClose: () => void;
  onSave: (course: Course) => void;
  onDelete?: (course: Course) => void;
}) {
  const initial = props.initial;
  const sectionStart = initial?.sections?.[0] || 1;
  const sectionEnd = initial?.sections?.[1] || Math.min(2, sectionStart);
  const [name, setName] = useState(initial?.name || "");
  const [teacher, setTeacher] = useState(initial?.teacher || "");
  const [place, setPlace] = useState(initial?.place || "");
  const [weekday, setWeekday] = useState(initial?.weekday || 1);
  const [beginSection, setBeginSection] = useState(sectionStart);
  const [endSection, setEndSection] = useState(sectionEnd);
  const [start, setStart] = useState(initial?.start || STARTS[sectionStart - 1]);
  const [end, setEnd] = useState(initial?.end || ENDS[sectionEnd - 1]);
  const [weeks, setWeeks] = useState(compactWeeks(initial?.weeks));
  const [localErr, setLocalErr] = useState("");

  function save() {
    const cleanName = name.trim();
    if (!cleanName) { setLocalErr("请填写课程名称。"); return; }
    if (beginSection < 1 || endSection < beginSection || endSection > 11) { setLocalErr("请选择有效的节次范围。"); return; }
    if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(start) || !/^([01]\d|2[0-3]):[0-5]\d$/.test(end) || end <= start) {
      setLocalErr("请设置有效时间，结束时间须晚于开始时间。"); return;
    }
    let parsedWeeks: number[] | undefined;
    try { parsedWeeks = parseWeeks(weeks); } catch (error) { setLocalErr(String(error)); return; }
    setLocalErr("");
    props.onSave({
      name: cleanName,
      teacher: teacher.trim() || undefined,
      place: place.trim(),
      weekday,
      start,
      end,
      sections: [beginSection, endSection],
      weeks: parsedWeeks,
      campus: "wuxi",
      localId: initial?.localId,
      sourceKey: initial?.sourceKey,
    });
  }

  function updateBeginSection(value: number) {
    setBeginSection(value);
    if (endSection < value) setEndSection(value);
    setStart(STARTS[value - 1]);
    if (endSection < value) setEnd(ENDS[value - 1]);
  }

  return (
    <Dialog open={props.open} onOpenChange={(_, data) => { if (!data.open) props.onClose(); }}>
      <DialogSurface>
        <DialogBody>
          <DialogTitle>{initial ? "编辑课程" : "添加课程"}</DialogTitle>
          <DialogContent className="stack event-form">
            <Field label="课程名称"><Input maxLength={100} value={name} onChange={(_, data) => setName(data.value)} placeholder="例如 通用英语" /></Field>
            <Field label="教师"><Input maxLength={100} value={teacher} onChange={(_, data) => setTeacher(data.value)} placeholder="可留空" /></Field>
            <Field label="地点"><Input maxLength={150} value={place} onChange={(_, data) => setPlace(data.value)} placeholder="例如 敏学楼 304" /></Field>
            <Field label="星期">
              <select className="course-select" value={weekday} onChange={(event) => setWeekday(Number(event.target.value))}>
                {DAY_NAMES.slice(1).map((day, index) => <option key={day} value={index + 1}>{day}</option>)}
              </select>
            </Field>
            <div className="course-section-fields">
              <Field label="开始节次"><select className="course-select" value={beginSection} onChange={(event) => updateBeginSection(Number(event.target.value))}>{STARTS.map((_, index) => <option key={index} value={index + 1}>第 {index + 1} 节</option>)}</select></Field>
              <Field label="结束节次"><select className="course-select" value={endSection} onChange={(event) => { const value = Math.max(beginSection, Number(event.target.value)); setEndSection(value); setEnd(ENDS[value - 1]); }}>{ENDS.map((_, index) => <option key={index} value={index + 1} disabled={index + 1 < beginSection}>第 {index + 1} 节</option>)}</select></Field>
            </div>
            <div className="course-section-fields">
              <Field label="开始时间"><Input type="time" value={start} onChange={(_, data) => setStart(data.value)} /></Field>
              <Field label="结束时间"><Input type="time" value={end} onChange={(_, data) => setEnd(data.value)} /></Field>
            </div>
            <Field label="上课周次"><Input value={weeks} onChange={(_, data) => setWeeks(data.value)} placeholder="1-3,6-8；留空表示每周" /></Field>
            {localErr || props.err ? <p className="hint warn" role="alert">{localErr || props.err}</p> : null}
          </DialogContent>
          <div className="row-between">
            {initial && props.onDelete ? <Button appearance="secondary" disabled={props.busy} onClick={() => props.onDelete?.(initial)}>删除课程</Button> : <span />}
            <div className="row-actions">
              <Button appearance="secondary" disabled={props.busy} onClick={props.onClose}>取消</Button>
              <Button appearance="primary" disabled={props.busy} onClick={save}>{props.busy ? "保存中…" : "保存"}</Button>
            </div>
          </div>
        </DialogBody>
      </DialogSurface>
    </Dialog>
  );
}

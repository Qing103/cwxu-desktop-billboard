import type { Course, CourseEditStore, Snapshot, TermCourseEdits } from "./types";

export const EMPTY_COURSE_EDITS: CourseEditStore = { terms: {} };

export function emptyTermEdits(): TermCourseEdits {
  return { hiddenKeys: [], overrides: {}, added: [] };
}

export function courseSourceKey(course: Course): string {
  const weeks = course.weeks?.length ? [...course.weeks].sort((a, b) => a - b) : null;
  return JSON.stringify([
    course.name,
    course.weekday,
    course.start,
    course.end,
    course.sections || null,
    weeks,
  ]);
}

export function applyCourseEdits(snap: Snapshot | null, edits: CourseEditStore): Snapshot | null {
  const semester = snap?.semester;
  if (!snap || !semester) return snap;
  const term = edits.terms[semester.semesterId] || emptyTermEdits();
  const hidden = new Set(term.hiddenKeys);
  const courses: Course[] = semester.courses.flatMap((course): Course[] => {
    const key = courseSourceKey(course);
    if (hidden.has(key)) return [];
    return [{ ...(term.overrides[key] || course), sourceKey: key }];
  });
  for (const local of term.added) courses.push({ ...local.course, localId: local.id });
  return { ...snap, semester: { ...semester, courses } };
}

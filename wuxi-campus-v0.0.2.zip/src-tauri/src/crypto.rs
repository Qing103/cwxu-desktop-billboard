use base64::{
    engine::general_purpose::{STANDARD, STANDARD_NO_PAD, URL_SAFE, URL_SAFE_NO_PAD},
    Engine,
};
use rand::rngs::OsRng;
use rsa::pkcs8::DecodePublicKey;
use rsa::traits::PublicKeyParts;
use rsa::{BigUint, Pkcs1v15Encrypt, RsaPublicKey};

/// Fallback SPKI from login_neu.js ?v=20260302 (docs 6.2).
pub const DEFAULT_PUB_B64: &str = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAnjA28DLKXZzxbKmo9/1WkVLf1mr+wtLXLXt6sC4WiBCtsbzF5ewm7ARZeAdS3iZtqlYPn6IcUoOw42H8nAK/tfFcIb6dZ1K0atn0U39oWCGPzYuKtLJeMuNZiDXVuAXtojrckOjLW9B3gUnaNGLuIx0fYe66l0o9WjU2cGLNZQfiIxs2h00z1EA9IdSnVxiVQWSD+lsP3JZXh2TT287la4Y4603SQNKTK/QvXfcmccwTEd1IW6HwGxD6QrkInBiHisKWxmveN7UDSaQRZ/J97G0YC32pD38WT53izXeK0p/kU/X37VP555um1wVWFvPIuc9I7gMP1+hq5a+X6c++tQIDAQAB";

pub fn sanitize_pub_b64(raw: &str) -> String {
    raw.chars()
        .filter(|c| c.is_ascii_alphanumeric() || *c == '+' || *c == '/' || *c == '=')
        .collect()
}

fn wrap_pem64(b64: &str) -> String {
    b64.as_bytes()
        .chunks(64)
        .map(|c| std::str::from_utf8(c).unwrap_or(""))
        .collect::<Vec<_>>()
        .join("\n")
}

pub fn parse_pub_key(pub_b64: &str) -> Option<RsaPublicKey> {
    let b64 = sanitize_pub_b64(pub_b64);
    if b64.len() < 200 {
        return None;
    }
    if let Ok(der) = STANDARD.decode(b64.as_bytes()) {
        if let Ok(k) = RsaPublicKey::from_public_key_der(&der) {
            return Some(k);
        }
    }
    let pem = format!(
        "-----BEGIN PUBLIC KEY-----\n{}\n-----END PUBLIC KEY-----",
        wrap_pem64(&b64)
    );
    RsaPublicKey::from_public_key_pem(&pem).ok()
}

pub fn encrypt_rsa(username: &str, password: &str, pub_b64: &str) -> crate::error::Result<String> {
    let key = parse_pub_key(pub_b64)
        .or_else(|| parse_pub_key(DEFAULT_PUB_B64))
        .ok_or("RSA 公钥无效")?;
    let plain = format!("{username}{password}");
    let mut rng = OsRng;
    let enc = key
        .encrypt(&mut rng, Pkcs1v15Encrypt, plain.as_bytes())
        .map_err(|e| format!("RSA 加密失败: {e}"))?;
    Ok(STANDARD.encode(enc))
}

fn valid_modulus(value: BigUint) -> Option<BigUint> {
    (512..=8192).contains(&value.bits()).then_some(value)
}

fn parse_modulus(raw: &str) -> Option<BigUint> {
    let value = raw.trim();

    // Some JWXT deployments return the whole SPKI key instead of a bare n.
    if let Some(key) = parse_pub_key(value) {
        if let Some(modulus) = valid_modulus(key.n().clone()) {
            return Some(modulus);
        }
    }

    let hex_value = value
        .strip_prefix("0x")
        .or_else(|| value.strip_prefix("0X"))
        .unwrap_or(value);
    let mut hex_digits = String::with_capacity(hex_value.len());
    let mut hex_only = true;
    for ch in hex_value.chars() {
        if ch.is_ascii_hexdigit() {
            hex_digits.push(ch);
        } else if ch.is_ascii_whitespace() || ch == ':' {
            // Accept keys formatted with visual separators.
        } else {
            hex_only = false;
            break;
        }
    }
    if hex_only && !hex_digits.is_empty() {
        if let Some(modulus) = BigUint::parse_bytes(hex_digits.as_bytes(), 16)
            .and_then(valid_modulus)
        {
            return Some(modulus);
        }
    }

    // The portal may encode the raw modulus bytes (or the whole SPKI DER) as
    // standard Base64 or Base64URL, with or without padding.
    let encoded = value
        .strip_prefix("base64:")
        .or_else(|| value.strip_prefix("BASE64:"))
        .unwrap_or(value);
    let compact: String = encoded.chars().filter(|ch| !ch.is_ascii_whitespace()).collect();
    let decoded = STANDARD
        .decode(compact.as_bytes())
        .or_else(|_| STANDARD_NO_PAD.decode(compact.as_bytes()))
        .or_else(|_| URL_SAFE.decode(compact.as_bytes()))
        .or_else(|_| URL_SAFE_NO_PAD.decode(compact.as_bytes()))
        .ok()?;

    if let Ok(decoded_text) = std::str::from_utf8(&decoded) {
        let digits: String = decoded_text
            .trim()
            .strip_prefix("0x")
            .or_else(|| decoded_text.trim().strip_prefix("0X"))
            .unwrap_or(decoded_text.trim())
            .chars()
            .filter(|ch| ch.is_ascii_hexdigit())
            .collect();
        if !digits.is_empty() {
            if let Some(modulus) = BigUint::parse_bytes(digits.as_bytes(), 16)
                .and_then(valid_modulus)
            {
                return Some(modulus);
            }
        }
    }

    if let Ok(key) = RsaPublicKey::from_public_key_der(&decoded) {
        if let Some(modulus) = valid_modulus(key.n().clone()) {
            return Some(modulus);
        }
    }

    valid_modulus(BigUint::from_bytes_be(&decoded))
}

fn parse_exponent(raw: &str) -> Option<BigUint> {
    let value = raw.trim();
    let unprefixed = value
        .strip_prefix("0x")
        .or_else(|| value.strip_prefix("0X"))
        .unwrap_or(value);

    // The common JSBN endpoint returns 10001 (hex) for exponent 65537.
    if unprefixed.eq_ignore_ascii_case("10001") {
        return BigUint::parse_bytes(unprefixed.as_bytes(), 16);
    }
    // Some endpoints serialize that same exponent as a JSON number/string.
    if unprefixed == "65537" {
        return Some(BigUint::from(65537u32));
    }
    if unprefixed.bytes().all(|byte| byte.is_ascii_hexdigit()) {
        return BigUint::parse_bytes(unprefixed.as_bytes(), 16);
    }

    let compact: String = unprefixed
        .chars()
        .filter(|ch| !ch.is_ascii_whitespace())
        .collect();
    let decoded = STANDARD
        .decode(compact.as_bytes())
        .or_else(|_| STANDARD_NO_PAD.decode(compact.as_bytes()))
        .or_else(|_| URL_SAFE.decode(compact.as_bytes()))
        .or_else(|_| URL_SAFE_NO_PAD.decode(compact.as_bytes()))
        .ok()?;
    if let Ok(text) = std::str::from_utf8(&decoded) {
        if let Some(decimal) = BigUint::parse_bytes(text.trim().as_bytes(), 10) {
            return Some(decimal);
        }
    }
    Some(BigUint::from_bytes_be(&decoded))
}

/// JWXT may expose the RSA modulus as hex or Base64; the exponent is commonly
/// the JSBN hex value `10001`. The form expects PKCS#1 v1.5 ciphertext in Base64.
pub fn encrypt_jwxt_password(
    password: &str,
    modulus_value: &str,
    exponent_value: &str,
) -> crate::error::Result<String> {
    let modulus = parse_modulus(modulus_value)
        .ok_or("教务系统返回的 modulus 不是可识别的十六进制或 Base64 公钥格式")?;
    let exponent = parse_exponent(exponent_value)
        .ok_or("教务系统公钥 exponent 格式无法识别")?;
    let key = RsaPublicKey::new(modulus, exponent).map_err(|_| "教务系统 RSA 公钥无效")?;
    let mut rng = OsRng;
    let ciphertext = key
        .encrypt(&mut rng, Pkcs1v15Encrypt, password.as_bytes())
        .map_err(|_| "教务密码长度不符合教务系统加密要求")?;
    Ok(STANDARD.encode(ciphertext))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn default_key_parses() {
        assert!(parse_pub_key(DEFAULT_PUB_B64).is_some());
        let c = encrypt_rsa("testuser", "testpass", DEFAULT_PUB_B64).expect("encrypt");
        assert!(c.len() > 80);
    }
}

//! Unofficial, local-only client for Wuxi University's student timetable.
//!
//! Credentials and cookies stay in memory for one synchronization. Redirects
//! are constrained to the official host and upgraded to HTTPS before use.

use crate::course;
use crate::crypto::encrypt_jwxt_password;
use crate::error::{AppError, Result};
use crate::models::Course;
use crate::periods::Campus;
use reqwest::header::{ACCEPT, CONTENT_TYPE, LOCATION, ORIGIN, REFERER};
use reqwest::redirect::Policy;
use reqwest::{Client, Response, StatusCode};
use scraper::{Html, Selector};
use serde_json::Value;
use std::time::{Duration, SystemTime, UNIX_EPOCH};
use url::Url;

const HOST: &str = "jwgl.cwxu.edu.cn";
const ORIGIN_URL: &str = "https://jwgl.cwxu.edu.cn";
const LOGIN_PATH: &str = "/jwglxt/xtgl/login_slogin.html";
const LOGIN_SUBMIT_PATH: &str = "/jwglxt/xtgl/login_slogin.html";
const PUBLIC_KEY_PATH: &str = "/jwglxt/xtgl/login_getPublicKey.html";
const COURSE_PATH: &str = "/jwglxt/kbcx/xskbcx_cxXsgrkb.html?gnmkdm=N2151";
const MAX_REDIRECTS: usize = 6;

fn http_error(err: reqwest::Error) -> AppError {
    AppError::Http(format!("无锡学院教务系统请求失败：{err}"))
}

fn timestamp() -> String {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_millis()
        .to_string()
}

fn secure_redirect_url(current: &Url, location: &str) -> Result<Url> {
    let mut next = current.join(location)?;
    if next.host_str() != Some(HOST) {
        return Err("教务系统登录跳转到了非官方地址，已停止请求。".into());
    }
    if next.scheme() == "http" {
        next.set_scheme("https")
            .map_err(|_| AppError::Msg("无法安全升级教务系统跳转地址。".into()))?;
        if next.port() == Some(80) {
            let _ = next.set_port(None);
        }
    }
    if next.scheme() != "https" {
        return Err("教务系统跳转不是 HTTPS，已停止请求。".into());
    }
    Ok(next)
}

async fn follow_https_redirects(client: &Client, mut response: Response) -> Result<Response> {
    for _ in 0..MAX_REDIRECTS {
        if !response.status().is_redirection() {
            if response.url().scheme() != "https" || response.url().host_str() != Some(HOST) {
                return Err("教务系统响应地址不安全，已停止请求。".into());
            }
            return Ok(response);
        }

        let current = response.url().clone();
        let location = response
            .headers()
            .get(LOCATION)
            .and_then(|v| v.to_str().ok())
            .ok_or("教务系统跳转缺少 Location 响应头")?;
        let next = secure_redirect_url(&current, location)?;
        response = client
            .get(next)
            .header(REFERER, current.as_str())
            .send()
            .await
            .map_err(http_error)?;
    }
    Err("教务系统跳转次数过多，已停止请求。".into())
}

async fn get_https(client: &Client, url: Url, referer: Option<&str>) -> Result<Response> {
    if url.scheme() != "https" || url.host_str() != Some(HOST) {
        return Err("教务系统请求地址不安全，已停止请求。".into());
    }
    let mut request = client.get(url);
    if let Some(value) = referer {
        request = request.header(REFERER, value);
    }
    let response = request.send().await.map_err(http_error)?;
    follow_https_redirects(client, response).await
}

fn check_status(status: StatusCode, phase: &str) -> Result<()> {
    if status.is_success() {
        Ok(())
    } else {
        Err(format!("无锡学院教务系统{phase}返回 HTTP {}。", status.as_u16()).into())
    }
}

fn hidden_csrf(html: &str) -> String {
    let document = Html::parse_document(html);
    let Ok(selector) = Selector::parse("input[name='csrftoken'], input#csrftoken") else {
        return String::new();
    };
    document
        .select(&selector)
        .next()
        .and_then(|input| input.value().attr("value"))
        .unwrap_or_default()
        .to_string()
}

fn json_field(value: &Value, name: &str) -> Option<String> {
    value
        .get(name)
        .or_else(|| value.get("data").and_then(|v| v.get(name)))
        .and_then(|v| v.as_str().map(str::to_string).or_else(|| v.as_u64().map(|n| n.to_string())))
        .filter(|v| !v.trim().is_empty())
}

fn login_challenge(body: &str) -> bool {
    let lower = body.to_lowercase();
    body.contains("验证码")
        || body.contains("二次验证")
        || lower.contains("captcha")
        || lower.contains("second_auth")
}

fn login_page(body: &str) -> bool {
    let lower = body.to_lowercase();
    lower.contains("login_slogin.html")
        || (body.contains("name=\"yhm\"") && body.contains("name=\"mm\""))
        || (body.contains("name='yhm'") && body.contains("name='mm'"))
}

fn client() -> Result<Client> {
    Client::builder()
        .cookie_store(true)
        .redirect(Policy::none())
        .timeout(Duration::from_secs(20))
        .build()
        .map_err(http_error)
}

/// Log into the official student portal and fetch one semester of courses.
/// The HTTP cookie jar is memory-only and is dropped when this function returns.
pub async fn fetch_courses(
    username: &str,
    password: &str,
    xnm: &str,
    xqm: &str,
) -> Result<Vec<Course>> {
    let client = client()?;
    let login_url = Url::parse(&format!("{ORIGIN_URL}{LOGIN_PATH}"))?;
    let login_page_response = get_https(&client, login_url.clone(), None).await?;
    check_status(login_page_response.status(), "登录页")?;
    let login_html = login_page_response.text().await.map_err(http_error)?;
    let csrf = hidden_csrf(&login_html);
    if csrf.is_empty() {
        return Err("教务登录页没有提供 csrftoken，已停止登录；请确认教务页面结构是否有变化。".into());
    }

    let public_key_url = Url::parse(&format!("{ORIGIN_URL}{PUBLIC_KEY_PATH}"))?;
    let mut public_key_url = public_key_url;
    public_key_url
        .query_pairs_mut()
        .append_pair("time", &timestamp());
    let key_response = get_https(&client, public_key_url, Some(login_url.as_str())).await?;
    check_status(key_response.status(), "公钥接口")?;
    let key_body = key_response.text().await.map_err(http_error)?;
    let key_json: Value = serde_json::from_str(&key_body)
        .map_err(|_| AppError::Msg("教务系统公钥响应无法识别。".into()))?;
    let modulus = json_field(&key_json, "modulus")
        .ok_or("教务系统公钥响应缺少 modulus 字段")?;
    let exponent = json_field(&key_json, "exponent")
        .ok_or("教务系统公钥响应缺少 exponent 字段")?;
    let encrypted_password = encrypt_jwxt_password(password, &modulus, &exponent)?;

    let mut submit_url = Url::parse(&format!("{ORIGIN_URL}{LOGIN_SUBMIT_PATH}"))?;
    submit_url
        .query_pairs_mut()
        .append_pair("time", &timestamp());
    let form = vec![
        ("csrftoken", csrf),
        ("language", "zh_CN".to_string()),
        ("ydType", String::new()),
        ("yhm", username.to_string()),
        ("mm", encrypted_password),
    ];
    let login_response = client
        .post(submit_url)
        .header(ORIGIN, ORIGIN_URL)
        .header(REFERER, login_url.as_str())
        .header("X-Requested-With", "XMLHttpRequest")
        .header(ACCEPT, "*/*")
        .form(&form)
        .send()
        .await
        .map_err(http_error)?;
    let login_response = follow_https_redirects(&client, login_response).await?;
    check_status(login_response.status(), "登录提交")?;
    let login_body = login_response.text().await.map_err(http_error)?;
    if login_challenge(&login_body) {
        return Err("教务系统要求验证码或额外验证；看板不会绕过验证，也不会读取浏览器会话。请使用官方教务网页登录和查看课表。".into());
    }
    if login_page(&login_body) {
        return Err("教务登录未成功，请检查本机保存的账号和密码。".into());
    }

    let course_url = Url::parse(&format!("{ORIGIN_URL}{COURSE_PATH}"))?;
    let course_referer = format!("{ORIGIN_URL}/jwglxt/kbcx/xskbcx_cxXsgrkb.html?gnmkdm=N2151&layout=default");
    let course_form = vec![
        ("xnm", xnm.to_string()),
        ("xqm", xqm.to_string()),
        ("kzlx", "ck".to_string()),
        ("xsdm", String::new()),
        ("kclbdm", String::new()),
        ("kclxdm", String::new()),
    ];
    let course_response = client
        .post(course_url)
        .header(ORIGIN, ORIGIN_URL)
        .header(REFERER, course_referer)
        .header("X-Requested-With", "XMLHttpRequest")
        .header(ACCEPT, "application/json, text/javascript, */*; q=0.01")
        .header(CONTENT_TYPE, "application/x-www-form-urlencoded;charset=UTF-8")
        .form(&course_form)
        .send()
        .await
        .map_err(http_error)?;
    let course_response = follow_https_redirects(&client, course_response).await?;
    check_status(course_response.status(), "课表接口")?;
    let response_body = course_response.text().await.map_err(http_error)?;
    if login_challenge(&response_body) {
        return Err("教务系统要求验证码或额外验证；看板不会绕过验证，也不会读取浏览器会话。请使用官方教务网页登录和查看课表。".into());
    }
    if login_page(&response_body) {
        return Err("教务会话未建立或已失效，请检查账号密码后重试。".into());
    }

    let data: Value = serde_json::from_str(&response_body)
        .map_err(|_| AppError::Msg("教务系统返回的课表不是可识别的 JSON。".into()))?;
    let rows = course::parse_arranged_list(&data);
    if rows.is_empty() {
        return Err("教务系统响应中没有识别到课表条目；未覆盖本地课表缓存。".into());
    }
    let courses = course::parse_courses(&rows, Some(Campus::Wuxi));
    if courses.is_empty() {
        return Err("教务系统返回了课表数据，但课程字段尚未全部匹配；未覆盖本地课表缓存。".into());
    }
    Ok(courses)
}

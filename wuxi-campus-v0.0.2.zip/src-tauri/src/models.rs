use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
#[serde(rename_all = "camelCase")]
pub struct Snapshot {
    pub fetched_at: String,
    pub network: String,
    pub logged_in: bool,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub username: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub card: Option<CardInfo>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub card_bills: Option<Vec<Bill>>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub card_spend: Option<Vec<DaySpend>>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub card_month: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub bills_truncated: Option<bool>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub net: Option<NetInfo>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub elec: Option<ElecInfo>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub courses_today: Option<Vec<Course>>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub semester: Option<SemesterTable>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub teaching_week: Option<u32>,
    /// 运行时探测：没网。不要当磁盘真源，写入 snapshot.json 前会清掉。
    #[serde(default)]
    pub offline: bool,
    /// 本机自定义日程。真源是 agenda.json，snapshot 里只是带给 UI。
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub agenda: Vec<AgendaItem>,
    pub errors: SnapshotErrors,
}

fn is_false(v: &bool) -> bool {
    !*v
}

fn is_zero_u32(v: &u32) -> bool {
    *v == 0
}

/// 重复规则。`freq` 只接受 `DAILY` 或 `WEEKLY`。
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "camelCase")]
pub struct RepetRule {
    pub freq: String,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub byday: Vec<String>,
    /// `DATE` 或 `NUMBER`
    pub endmode: String,
    /// `DATE` 时的本地 `YYYY-MM-DD`。
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub time: Option<String>,
    #[serde(default, skip_serializing_if = "is_zero_u32")]
    pub num: u32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AgendaItem {
    pub id: String,
    pub name: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub note: Option<String>,
    /// 本地 `YYYY-MM-DDTHH:MM`
    pub start: String,
    pub end: String,
    #[serde(default)]
    pub remind: bool,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub remind_minutes: Option<u32>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub location: Option<String>,
    /// 提醒代码：1、2、15、3、4、5、6、7。
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub remind_code: Option<String>,
    /// 代码 7：前一天的 HH:MM。
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub set_time: Option<String>,
    /// 重复只存这一条，界面按 `repet_rule` 展开。
    #[serde(default, skip_serializing_if = "is_false")]
    pub is_repet: bool,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub repet_rule: Option<RepetRule>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Course {
    pub name: String,
    pub place: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub teacher: Option<String>,
    pub start: String,
    pub end: String,
    pub weekday: u8,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub weeks: Option<Vec<u32>>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub sections: Option<(u32, u32)>,
    /// `wuxi`，兼容历史 `nanhu` / `hunnan` 缓存。
    #[serde(skip_serializing_if = "Option::is_none")]
    pub campus: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
#[serde(rename_all = "camelCase")]
pub struct TermWeek {
    pub n: u32,
    pub start: String,
    pub end: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SemesterTable {
    pub semester_id: String,
    pub label: String,
    pub week1_monday: String,
    pub fetched_at: String,
    pub courses: Vec<Course>,
    /// 教务 `getTermWeeks` 的官方教学周（含起止日）。旧缓存没有此字段。
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub term_weeks: Vec<TermWeek>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct SnapshotErrors {
    #[serde(skip_serializing_if = "Option::is_none")]
    pub card: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub net: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub elec: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub course: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub auth: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CardInfo {
    pub balance: f64,
    pub subsidy: f64,
    pub status: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Bill {
    pub time: String,
    pub subject: String,
    pub amount: f64,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub fee: Option<f64>,
    pub balance_after: f64,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub station: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DaySpend {
    pub date: String,
    pub spend: f64,
    pub recharge: f64,
    pub count: u32,
    pub bills: Vec<Bill>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct NetInfo {
    pub balance: f64,
    pub month_bytes: u64,
    pub month_seconds: u64,
    pub month_times: u64,
    /// 门户 getWlzzList 是否解析到了流量字段。false 时 UI 应沿用上次或显示 —，不要当成真的 0B。
    #[serde(default)]
    pub flow_from_portal: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ElecInfo {
    pub unbound: bool,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub remain_kwh: Option<f64>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub room_no: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub room_label: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub last_read_at: Option<String>,
    /// 23:00–06:00 电费接口没连上，度数是上一次成功的读数。
    #[serde(default)]
    pub stale: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AppSettings {
    pub room_no: String,
    #[serde(default = "default_card_warn")]
    pub card_warn: f64,
    #[serde(default = "default_net_warn")]
    pub net_warn: f64,
    #[serde(default = "default_elec_warn")]
    pub elec_warn: f64,
    #[serde(default = "default_theme")]
    pub theme: String,
    #[serde(default = "default_true")]
    pub autostart: bool,
    #[serde(default = "default_true")]
    pub remember_password: bool,
    #[serde(default = "default_true")]
    pub auto_login: bool,
    #[serde(default)]
    pub last_username: String,
    /// 本地看板昵称，不发往学校服务。
    #[serde(default)]
    pub display_name: String,
    /// 是否完成过本地资料首次设置。
    #[serde(default)]
    pub profile_setup_complete: bool,
    /// 教务账号名；密码单独保存在系统凭据库。
    #[serde(default)]
    pub jwxt_username: String,
    /// 系统凭据库中是否存在教务密码，不保存密码本身。
    #[serde(default)]
    pub jwxt_password_saved: bool,
    #[serde(default)]
    pub island_x: Option<f64>,
    #[serde(default)]
    pub island_y: Option<f64>,
    /// 本学期第一周周一 YYYY-MM-DD；空则用教务校历。
    #[serde(default)]
    pub week1_monday: String,
    /// 折叠后自动藏进屏幕上沿。
    #[serde(default = "default_true")]
    pub auto_hide: bool,
    /// 自动隐藏后，用全局快捷键把岛叫出来。不打开窗口。
    #[serde(default = "default_true")]
    pub auto_hide_hotkey: bool,
    /// 自动隐藏后，在隐藏处悬停 1 秒把岛叫出来。不打开窗口。
    #[serde(default = "default_true")]
    pub auto_hide_hover: bool,
    #[serde(default = "default_reveal_hotkey")]
    pub reveal_hotkey: String,
    #[serde(default = "default_true")]
    pub class_remind: bool,
    #[serde(default = "default_remind_minutes")]
    pub class_remind_minutes: u32,
    /// off / offline / boot / hotspot / manual。空和未知都当关闭。
    #[serde(default)]
    pub campus_wifi_mode: String,
    /// 无线配置名，空则用 NEU。
    #[serde(default)]
    pub campus_wifi_ssid: String,
    /// 模式 hotspot：离开这个网络后才去连校园网。
    #[serde(default)]
    pub campus_hotspot_ssid: String,
    /// 跳过登录进窗口。卡、网、电、课仍不可用。
    #[serde(default)]
    pub skip_login: bool,
    /// 免流文件互传的说明勾过不再提示。
    #[serde(default)]
    pub share_hint_dismissed: bool,
}

impl Default for AppSettings {
    fn default() -> Self {
        Self {
            room_no: String::new(),
            card_warn: 100.0,
            net_warn: 10.0,
            elec_warn: 20.0,
            theme: "system".into(),
            autostart: true,
            remember_password: true,
            auto_login: true,
            last_username: String::new(),
            display_name: String::new(),
            profile_setup_complete: false,
            jwxt_username: String::new(),
            jwxt_password_saved: false,
            island_x: None,
            island_y: None,
            week1_monday: String::new(),
            auto_hide: true,
            auto_hide_hotkey: true,
            auto_hide_hover: true,
            reveal_hotkey: default_reveal_hotkey(),
            class_remind: true,
            class_remind_minutes: default_remind_minutes(),
            campus_wifi_mode: String::new(),
            campus_wifi_ssid: String::new(),
            campus_hotspot_ssid: String::new(),
            skip_login: false,
            share_hint_dismissed: false,
        }
    }
}

fn default_true() -> bool {
    true
}

fn default_theme() -> String {
    "system".into()
}

fn default_card_warn() -> f64 {
    100.0
}

fn default_net_warn() -> f64 {
    10.0
}

fn default_elec_warn() -> f64 {
    20.0
}

fn default_reveal_hotkey() -> String {
    "Ctrl+Q".into()
}

fn default_remind_minutes() -> u32 {
    15
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "status", rename_all = "snake_case")]
pub enum LoginOutcome {
    Ok,
    NeedSms {
        #[serde(rename = "phoneMask")]
        phone_mask: String,
        #[serde(rename = "captchaPng")]
        captcha_png: String,
    },
}

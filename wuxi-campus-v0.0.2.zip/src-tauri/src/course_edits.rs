//! 本机教务课表编辑：覆盖项、隐藏的原始课程和用户新增课程。

use crate::error::{AppError, Result};
use crate::models::Course;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::fs;
use std::path::Path;

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
#[serde(rename_all = "camelCase")]
pub struct CourseEditStore {
    #[serde(default)]
    pub terms: HashMap<String, TermCourseEdits>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
#[serde(rename_all = "camelCase")]
pub struct TermCourseEdits {
    #[serde(default)]
    pub hidden_keys: Vec<String>,
    #[serde(default)]
    pub overrides: HashMap<String, Course>,
    #[serde(default)]
    pub added: Vec<LocalCourse>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct LocalCourse {
    pub id: String,
    pub course: Course,
}

pub fn load(dir: &Path) -> CourseEditStore {
    fs::read(dir.join("course_edits.json"))
        .ok()
        .and_then(|bytes| serde_json::from_slice(&bytes).ok())
        .unwrap_or_default()
}

pub fn save(dir: &Path, mut store: CourseEditStore) -> Result<CourseEditStore> {
    if store.terms.len() > 40 {
        return Err(AppError::Msg("课程编辑学期数量超出限制。".into()));
    }
    for edits in store.terms.values_mut() {
        if edits.added.len() > 500 || edits.overrides.len() > 1000 || edits.hidden_keys.len() > 1000 {
            return Err(AppError::Msg("课程编辑数量超出限制。".into()));
        }
        edits.hidden_keys.retain(|key| !key.trim().is_empty());
        edits.hidden_keys.sort();
        edits.hidden_keys.dedup();
        for course in edits.overrides.values_mut() {
            normalize_course(course)?;
        }
        let mut ids = std::collections::HashSet::new();
        for local in &mut edits.added {
            local.id = local.id.trim().to_string();
            if local.id.is_empty() || local.id.len() > 80 || !ids.insert(local.id.clone()) {
                return Err(AppError::Msg("新增课程标识无效。".into()));
            }
            normalize_course(&mut local.course)?;
        }
    }
    fs::write(
        dir.join("course_edits.json"),
        serde_json::to_vec_pretty(&store)?,
    )?;
    Ok(store)
}

fn normalize_course(course: &mut Course) -> Result<()> {
    course.name = course.name.trim().to_string();
    if course.name.is_empty() || course.name.chars().count() > 100 {
        return Err(AppError::Msg("课程名称不能为空且最多 100 个字。".into()));
    }
    if !(1..=7).contains(&course.weekday) {
        return Err(AppError::Msg("课程星期无效。".into()));
    }
    if let Some((start, end)) = course.sections {
        if start == 0 || end < start || end > 11 {
            return Err(AppError::Msg("节次范围须在第 1 至 11 节内。".into()));
        }
    }
    let start = parse_minutes(&course.start).ok_or("课程开始时间无效。")?;
    let end = parse_minutes(&course.end).ok_or("课程结束时间无效。")?;
    if end <= start {
        return Err(AppError::Msg("课程结束时间必须晚于开始时间。".into()));
    }
    if let Some(teacher) = course.teacher.as_mut() {
        *teacher = teacher.trim().to_string();
        if teacher.chars().count() > 100 {
            return Err(AppError::Msg("教师姓名最多 100 个字。".into()));
        }
    }
    if course.teacher.as_deref().is_some_and(|teacher| teacher.is_empty()) {
        course.teacher = None;
    }
    course.place = course.place.trim().to_string();
    if course.place.chars().count() > 150 {
        return Err(AppError::Msg("地点最多 150 个字。".into()));
    }
    if let Some(weeks) = course.weeks.as_mut() {
        if weeks.len() > 30 || weeks.iter().any(|week| !(1..=30).contains(week)) {
            return Err(AppError::Msg("周次须在第 1 至 30 周内。".into()));
        }
        weeks.sort_unstable();
        weeks.dedup();
    }
    if course.weeks.as_ref().is_some_and(|weeks| weeks.is_empty()) {
        course.weeks = None;
    }
    if course.campus.as_deref().unwrap_or_default().trim().is_empty() {
        course.campus = Some("wuxi".into());
    }
    Ok(())
}

fn parse_minutes(raw: &str) -> Option<u16> {
    let mut parts = raw.split(':');
    let hour = parts.next()?.parse::<u16>().ok()?;
    let minute = parts.next()?.parse::<u16>().ok()?;
    if parts.next().is_some() || hour > 23 || minute > 59 {
        return None;
    }
    Some(hour * 60 + minute)
}

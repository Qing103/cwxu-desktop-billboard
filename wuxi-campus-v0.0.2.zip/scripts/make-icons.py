"""Regenerate the generic campus icons using the shared Node.js generator."""
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[1]
subprocess.run(["node", str(ROOT / "scripts" / "write-icons.mjs")], check=True)

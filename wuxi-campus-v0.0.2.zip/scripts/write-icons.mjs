import { deflateSync } from "node:zlib";
import { mkdirSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const iconDir = join(root, "src-tauri", "icons");
const assetsDir = join(root, "assets");
mkdirSync(iconDir, { recursive: true });
mkdirSync(assetsDir, { recursive: true });

// A generic campus-building mark: deliberately not a university seal or logo.
const blue = [14, 107, 117, 255];
const white = [255, 255, 255, 255];
const transparent = [0, 0, 0, 0];
const sizes = [16, 24, 32, 48, 64, 128, 256];

function crc32(buf) {
  let crc = ~0;
  for (const byte of buf) {
    crc ^= byte;
    for (let bit = 0; bit < 8; bit++) crc = (crc >>> 1) ^ (0xedb88320 & -(crc & 1));
  }
  return ~crc >>> 0;
}

function pngChunk(type, data) {
  const typeBytes = Buffer.from(type);
  const length = Buffer.alloc(4);
  length.writeUInt32BE(data.length);
  const checksum = Buffer.alloc(4);
  checksum.writeUInt32BE(crc32(Buffer.concat([typeBytes, data])));
  return Buffer.concat([length, typeBytes, data, checksum]);
}

function inRoundedSquare(x, y) {
  const left = 14;
  const top = 14;
  const right = 242;
  const bottom = 242;
  const radius = 46;
  const cx = Math.max(left + radius, Math.min(x, right - radius));
  const cy = Math.max(top + radius, Math.min(y, bottom - radius));
  return (x - cx) ** 2 + (y - cy) ** 2 <= radius ** 2;
}

function inRect(x, y, left, top, right, bottom) {
  return x >= left && x <= right && y >= top && y <= bottom;
}

function inTriangle(x, y, a, b, c) {
  const sign = (p1, p2, p3) => (p1.x - p3.x) * (p2.y - p3.y) - (p2.x - p3.x) * (p1.y - p3.y);
  const point = { x, y };
  const d1 = sign(point, a, b);
  const d2 = sign(point, b, c);
  const d3 = sign(point, c, a);
  return !([d1, d2, d3].some((v) => v < 0) && [d1, d2, d3].some((v) => v > 0));
}

function drawColor(x, y) {
  let color = inRoundedSquare(x, y) ? blue : transparent;
  const roof = inTriangle(x, y, { x: 52, y: 114 }, { x: 128, y: 62 }, { x: 204, y: 114 });
  const building = roof
    || inRect(x, y, 64, 108, 192, 122)
    || inRect(x, y, 76, 120, 180, 187)
    || inRect(x, y, 58, 187, 198, 199)
    || inRect(x, y, 72, 201, 184, 211);
  if (building && color[3]) color = white;

  const windows = inRect(x, y, 87, 134, 102, 151)
    || inRect(x, y, 112, 134, 127, 151)
    || inRect(x, y, 137, 134, 152, 151)
    || inRect(x, y, 162, 134, 177, 151)
    || inRect(x, y, 116, 159, 140, 187);
  if (windows && color[3]) color = blue;
  return color;
}

function renderRgba(size) {
  const pixels = Buffer.alloc(size * size * 4);
  const scale = 256 / size;
  const sampleGrid = 4;
  const sampleCount = sampleGrid * sampleGrid;

  for (let py = 0; py < size; py++) {
    for (let px = 0; px < size; px++) {
      const sums = [0, 0, 0, 0];
      for (let sy = 0; sy < sampleGrid; sy++) {
        for (let sx = 0; sx < sampleGrid; sx++) {
          const x = (px + (sx + 0.5) / sampleGrid) * scale;
          const y = (py + (sy + 0.5) / sampleGrid) * scale;
          const color = drawColor(x, y);
          for (let channel = 0; channel < 4; channel++) sums[channel] += color[channel];
        }
      }
      const offset = (py * size + px) * 4;
      for (let channel = 0; channel < 4; channel++) pixels[offset + channel] = Math.round(sums[channel] / sampleCount);
    }
  }
  return pixels;
}

function encodePng(size, pixels) {
  const raw = Buffer.alloc((size * 4 + 1) * size);
  for (let y = 0; y < size; y++) {
    const row = y * (size * 4 + 1);
    raw[row] = 0;
    pixels.copy(raw, row + 1, y * size * 4, (y + 1) * size * 4);
  }

  const header = Buffer.alloc(13);
  header.writeUInt32BE(size, 0);
  header.writeUInt32BE(size, 4);
  header[8] = 8;
  header[9] = 6;
  return Buffer.concat([
    Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]),
    pngChunk("IHDR", header),
    pngChunk("IDAT", deflateSync(raw)),
    pngChunk("IEND", Buffer.alloc(0)),
  ]);
}

const images = new Map();
for (const size of sizes) {
  const pixels = renderRgba(size);
  const encoded = encodePng(size, pixels);
  images.set(size, { pixels, encoded });
  writeFileSync(join(iconDir, `${size}x${size}.png`), encoded);
}

writeFileSync(join(iconDir, "henry.32.png"), images.get(32).encoded);
writeFileSync(join(iconDir, "tray-32.png"), images.get(32).encoded);
writeFileSync(join(iconDir, "tray-32.rgba"), images.get(32).pixels);

// Keep historical asset paths harmless while replacing their old university crest.
const blankAsset = encodePng(1, Buffer.alloc(4));
writeFileSync(join(assetsDir, "nidong-app-icon.png"), blankAsset);
writeFileSync(join(assetsDir, "nidong-tray-icon.png"), blankAsset);

// Tauri falls back to src-tauri/icons/icon.ico on Windows when no bundle icon
// is configured. A transparent icon removes the title-bar mark entirely.
const blankFrame = encodePng(16, Buffer.alloc(16 * 16 * 4));
const icoHeader = Buffer.alloc(6);
icoHeader.writeUInt16LE(1, 2);
icoHeader.writeUInt16LE(1, 4);
const entry = Buffer.alloc(16);
entry[0] = 16;
entry[1] = 16;
entry.writeUInt16LE(1, 4);
entry.writeUInt16LE(32, 6);
entry.writeUInt32LE(blankFrame.length, 8);
entry.writeUInt32LE(22, 12);
writeFileSync(join(iconDir, "icon.ico"), Buffer.concat([icoHeader, entry, blankFrame]));

console.log("Regenerated neutral tray/share icons; old crest pixels were cleared and the title-bar icon is transparent.");
